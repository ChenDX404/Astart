Readme.txt

目录结构说明：
- src/
  - astar_weighted.py            A* 与 Weighted A* 核心算法实现（含 tie-breaking 改进）
  - maze_gen.py                  迷宫/网格数据生成与读写
  - run_experiments.py           批量实验脚本：对比不同 w 下的 expansions/time/cost，并输出CSV与图表
  - make_gif.py                  生成演示 GIF（不同 w 的路径与开销对比）
  - requirements.txt             Python依赖
  - data/
    - sample_grid.txt            示例网格数据（0可通行，1障碍）
  - results/
    - results.csv                批量实验结果表
    - expansions_vs_weight.png   节点扩展数随 w 变化
    - time_s_vs_weight.png       运行时间随 w 变化
    - path_cost_vs_weight.png    路径代价随 w 变化
    - weighted_astar_demo.gif    动画演示

运行方法（建议Python 3.9+）：
1) 安装依赖：pip install -r requirements.txt
2) 批量实验：python run_experiments.py
3) 生成演示GIF：python make_gif.py


