"""
A* / Weighted A* pathfinding on grid mazes.
- Supports 4-neighbor or 8-neighbor movement
- Supports Weighted A* (w>=1). w=1 => standard A*
- Tie-breaking prefers larger g (deeper) to reduce zig-zag in some cases
"""
from __future__ import annotations
from typing import List, Tuple, Optional, Dict
import heapq
import math
import time

Coord = Tuple[int, int]

def manhattan(a: Coord, b: Coord) -> float:
    return abs(a[0]-b[0]) + abs(a[1]-b[1])

def octile(a: Coord, b: Coord) -> float:
    dx = abs(a[0]-b[0])
    dy = abs(a[1]-b[1])
    F = math.sqrt(2) - 1
    return (F * min(dx, dy) + max(dx, dy))

def neighbors(pos: Coord, allow_diagonal: bool) -> List[Tuple[Coord, float]]:
    r, c = pos
    nbs = [((r-1,c),1.0), ((r+1,c),1.0), ((r,c-1),1.0), ((r,c+1),1.0)]
    if allow_diagonal:
        d = math.sqrt(2)
        nbs += [((r-1,c-1),d), ((r-1,c+1),d), ((r+1,c-1),d), ((r+1,c+1),d)]
    return nbs

def reconstruct(came_from: Dict[Coord, Coord], start: Coord, goal: Coord) -> List[Coord]:
    cur = goal
    path = [cur]
    while cur != start:
        cur = came_from[cur]
        path.append(cur)
    path.reverse()
    return path

def astar(grid: List[List[int]], start: Coord, goal: Coord, *,
          weight: float = 1.0,
          allow_diagonal: bool = False,
          tie_break: str = "larger_g") -> Tuple[Optional[List[Coord]], Dict[str, float]]:
    """
    grid: 0 free, 1 blocked
    returns: path (list of coords) or None, and stats
    """
    assert weight >= 1.0
    H = octile if allow_diagonal else manhattan

    rows, cols = len(grid), len(grid[0])
    def in_bounds(p: Coord) -> bool:
        return 0 <= p[0] < rows and 0 <= p[1] < cols

    open_heap = []
    g: Dict[Coord, float] = {start: 0.0}
    came_from: Dict[Coord, Coord] = {}

    counter = 0
    h0 = H(start, goal)
    f0 = g[start] + weight*h0
    tie0 = -g[start] if tie_break == "larger_g" else g[start]
    heapq.heappush(open_heap, (f0, tie0, counter, start))
    counter += 1

    closed = set()
    expansions = 0
    t0 = time.perf_counter()

    while open_heap:
        _, _, _, cur = heapq.heappop(open_heap)
        if cur in closed:
            continue
        if cur == goal:
            t1 = time.perf_counter()
            path = reconstruct(came_from, start, goal)
            return path, {
                "time_s": t1 - t0,
                "expansions": float(expansions),
                "path_cost": float(g[cur]),
                "path_len": float(len(path))
            }
        closed.add(cur)
        expansions += 1

        for nb, step_cost in neighbors(cur, allow_diagonal):
            if not in_bounds(nb): 
                continue
            if grid[nb[0]][nb[1]] == 1:
                continue
            tentative = g[cur] + step_cost
            if nb in closed and tentative >= g.get(nb, float("inf")):
                continue
            if tentative < g.get(nb, float("inf")):
                came_from[nb] = cur
                g[nb] = tentative
                h = H(nb, goal)
                f = tentative + weight*h
                tiev = -tentative if tie_break == "larger_g" else tentative
                heapq.heappush(open_heap, (f, tiev, counter, nb))
                counter += 1

    t1 = time.perf_counter()
    return None, {"time_s": t1 - t0, "expansions": float(expansions), "path_cost": float("nan"), "path_len": 0.0}
