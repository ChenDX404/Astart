"""
Create a short GIF showing path planning as weight changes.
"""
from __future__ import annotations
import os
import numpy as np
import matplotlib.pyplot as plt
import imageio.v2 as imageio
from astar_weighted import astar
from maze_gen import gen_connected_grid

def frame(grid, path, start, goal, title, out_png):
    img = np.array(grid, dtype=float)
    if path:
        for r,c in path:
            img[r,c] = 0.5
    img[start[0], start[1]] = 0.25
    img[goal[0], goal[1]] = 0.75
    plt.figure(figsize=(5,5))
    plt.imshow(img, interpolation="nearest")
    plt.title(title)
    plt.axis("off")
    plt.tight_layout()
    plt.savefig(out_png, dpi=160)
    plt.close()

def make_gif(out_dir: str):
    os.makedirs(out_dir, exist_ok=True)
    n=40
    grid = gen_connected_grid(n,n,0.32,seed=7)
    start, goal = (0,0), (n-1,n-1)
    weights = [1.0, 1.2, 1.5, 2.0]
    pngs=[]
    for w in weights:
        path, stats = astar(grid, start, goal, weight=w, allow_diagonal=False)
        title = f"Weighted A* (w={w}) | expansions={int(stats['expansions'])} | cost={stats['path_cost']:.1f}"
        out_png = os.path.join(out_dir, f"frame_w{str(w).replace('.','_')}.png")
        frame(grid, path, start, goal, title, out_png)
        pngs.append(out_png)
    images = [imageio.imread(p) for p in pngs]
    gif_path = os.path.join(out_dir, "weighted_astar_demo.gif")
    imageio.mimsave(gif_path, images, duration=1.2, loop=0)
    return gif_path

if __name__ == "__main__":
    out_dir = os.path.join(os.path.dirname(__file__), "results")
    gif = make_gif(out_dir)
    print("GIF:", gif)
