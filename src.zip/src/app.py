import tkinter as tk
import random
import math
import heapq
from typing import Dict, Tuple, Optional, List, Set

Coord = Tuple[int, int]

# --------- Maze generation (guarantee connectivity with a random carve) ----------
def gen_connected_grid(n: int, obstacle_p: float, seed: int, start=(0, 0), goal=None):
    random.seed(seed)
    if goal is None:
        goal = (n - 1, n - 1)
    grid = [[0 for _ in range(n)] for _ in range(n)]
    for r in range(n):
        for c in range(n):
            if (r, c) in (start, goal):
                continue
            grid[r][c] = 1 if random.random() < obstacle_p else 0

    # carve a random walk toward goal
    r, c = start
    gr, gc = goal
    grid[r][c] = 0
    steps = 0
    while (r, c) != (gr, gc) and steps < n * n * 10:
        steps += 1
        moves = []
        if r < gr: moves.append((r + 1, c))
        if r > gr: moves.append((r - 1, c))
        if c < gc: moves.append((r, c + 1))
        if c > gc: moves.append((r, c - 1))
        cand = moves + [(r + 1, c), (r - 1, c), (r, c + 1), (r, c - 1)]
        nr, nc = random.choice(cand)
        if 0 <= nr < n and 0 <= nc < n:
            r, c = nr, nc
            grid[r][c] = 0

    grid[start[0]][start[1]] = 0
    grid[goal[0]][goal[1]] = 0
    return grid

# --------- A* / Weighted A* with step-by-step yielding ----------
def manhattan(a: Coord, b: Coord) -> float:
    return abs(a[0] - b[0]) + abs(a[1] - b[1])

def neighbors4(p: Coord) -> List[Coord]:
    r, c = p
    return [(r - 1, c), (r + 1, c), (r, c - 1), (r, c + 1)]

def reconstruct(came_from: Dict[Coord, Coord], start: Coord, goal: Coord) -> List[Coord]:
    cur = goal
    path = [cur]
    while cur != start:
        cur = came_from[cur]
        path.append(cur)
    path.reverse()
    return path

def astar_steps(grid, start: Coord, goal: Coord, weight: float = 1.0):
    n = len(grid)
    def inb(p): return 0 <= p[0] < n and 0 <= p[1] < n

    open_heap = []
    g: Dict[Coord, float] = {start: 0.0}
    came_from: Dict[Coord, Coord] = {}
    closed: Set[Coord] = set()

    counter = 0
    f0 = weight * manhattan(start, goal)
    # (f, tie=-g, counter, node)
    heapq.heappush(open_heap, (f0, -0.0, counter, start))
    counter += 1

    expansions = 0

    while open_heap:
        _, _, _, cur = heapq.heappop(open_heap)
        if cur in closed:
            continue

        closed.add(cur)
        expansions += 1

        # yield current state for visualization
        yield ("expand", cur, set(closed), {x[3] for x in open_heap}, expansions)

        if cur == goal:
            path = reconstruct(came_from, start, goal)
            yield ("done", path, expansions, g[cur])
            return

        for nb in neighbors4(cur):
            if not inb(nb):
                continue
            if grid[nb[0]][nb[1]] == 1:
                continue
            tentative = g[cur] + 1.0
            if tentative < g.get(nb, float("inf")):
                came_from[nb] = cur
                g[nb] = tentative
                f = tentative + weight * manhattan(nb, goal)
                heapq.heappush(open_heap, (f, -tentative, counter, nb))
                counter += 1

    yield ("fail", None)

# --------- Tkinter visualization ----------
class App:
    def __init__(self, root):
        self.root = root
        self.root.title("A* / Weighted A* 可视化演示（加分版）")

        self.n = 40
        self.cell = 14
        self.start = (0, 0)
        self.goal = (self.n - 1, self.n - 1)

        self.grid = gen_connected_grid(self.n, obstacle_p=0.30, seed=7, start=self.start, goal=self.goal)

        top = tk.Frame(root)
        top.pack(fill="x")

        tk.Label(top, text="w=").pack(side="left")
        self.w_var = tk.StringVar(value="1.0")
        tk.OptionMenu(top, self.w_var, "1.0", "1.2", "1.5", "2.0").pack(side="left")

        tk.Button(top, text="生成新迷宫", command=self.new_maze).pack(side="left", padx=6)
        tk.Button(top, text="开始搜索", command=self.start_search).pack(side="left", padx=6)
        tk.Button(top, text="清空轨迹", command=self.redraw).pack(side="left", padx=6)

        self.info = tk.Label(top, text="提示：先生成迷宫，再开始搜索。")
        self.info.pack(side="left", padx=10)

        self.canvas = tk.Canvas(root, width=self.n * self.cell, height=self.n * self.cell)
        self.canvas.pack()

        self.rects = [[None for _ in range(self.n)] for _ in range(self.n)]
        self.draw_base()

        self._runner = None

    def draw_base(self):
        self.canvas.delete("all")
        for r in range(self.n):
            for c in range(self.n):
                x0, y0 = c * self.cell, r * self.cell
                x1, y1 = x0 + self.cell, y0 + self.cell
                color = "white" if self.grid[r][c] == 0 else "black"
                rect = self.canvas.create_rectangle(x0, y0, x1, y1, fill=color, outline="#ddd")
                self.rects[r][c] = rect

        # start & goal
        sr, sc = self.start
        gr, gc = self.goal
        self.canvas.itemconfig(self.rects[sr][sc], fill="deepskyblue")
        self.canvas.itemconfig(self.rects[gr][gc], fill="gold")

    def redraw(self):
        self.draw_base()
        self.info.config(text="已清空轨迹。")

    def new_maze(self):
        seed = random.randint(0, 9999)
        self.grid = gen_connected_grid(self.n, obstacle_p=0.30, seed=seed, start=self.start, goal=self.goal)
        self.redraw()
        self.info.config(text=f"已生成新迷宫（seed={seed}）。")

    def start_search(self):
        self.redraw()
        w = float(self.w_var.get())
        self._runner = astar_steps(self.grid, self.start, self.goal, weight=w)
        self.info.config(text=f"开始搜索：Weighted A* (w={w}) ...")
        self.step()

    def step(self):
        if self._runner is None:
            return
        try:
            event = next(self._runner)
        except StopIteration:
            self._runner = None
            return

        if event[0] == "expand":
            _, cur, closed, open_set, expansions = event
            # paint closed (visited)
            for (r, c) in closed:
                if (r, c) not in (self.start, self.goal) and self.grid[r][c] == 0:
                    self.canvas.itemconfig(self.rects[r][c], fill="#b7e3ff")  # visited
            # paint current
            r, c = cur
            if (r, c) not in (self.start, self.goal):
                self.canvas.itemconfig(self.rects[r][c], fill="#4aa3df")
            self.info.config(text=f"扩展节点数 expansions={expansions}")

            self.root.after(10, self.step)  # speed: 10ms per expansion

        elif event[0] == "done":
            _, path, expansions, cost = event
            for (r, c) in path:
                if (r, c) not in (self.start, self.goal):
                    self.canvas.itemconfig(self.rects[r][c], fill="limegreen")
            self.info.config(text=f"完成！expansions={expansions}, path_cost={cost:.0f} （绿线为路径）")
            self._runner = None

        elif event[0] == "fail":
            self.info.config(text="未找到路径（理论上很少发生，因为生成时保证连通）")
            self._runner = None

if __name__ == "__main__":
    root = tk.Tk()
    App(root)
    root.mainloop()
