"""
Generate random connected grid mazes (0 free, 1 blocked) with guaranteed connectivity by carving a random walk.
"""
from __future__ import annotations
from typing import List, Tuple
import random

Coord = Tuple[int,int]

def gen_connected_grid(n: int, m: int, obstacle_p: float, seed: int, start: Coord=(0,0), goal: Coord=None) -> List[List[int]]:
    random.seed(seed)
    if goal is None:
        goal = (n-1, m-1)
    grid = [[0 for _ in range(m)] for _ in range(n)]

    for r in range(n):
        for c in range(m):
            if (r,c) in (start, goal):
                continue
            grid[r][c] = 1 if random.random() < obstacle_p else 0

    r, c = start
    gr, gc = goal
    grid[r][c] = 0
    steps = 0
    while (r,c) != (gr,gc) and steps < n*m*10:
        steps += 1
        moves = []
        if r < gr: moves.append((r+1,c))
        if r > gr: moves.append((r-1,c))
        if c < gc: moves.append((r,c+1))
        if c > gc: moves.append((r,c-1))
        cand = moves + [(r+1,c),(r-1,c),(r,c+1),(r,c-1)]
        nr, nc = random.choice(cand)
        if 0 <= nr < n and 0 <= nc < m:
            r, c = nr, nc
            grid[r][c] = 0

    grid[start[0]][start[1]] = 0
    grid[goal[0]][goal[1]] = 0
    return grid

def save_grid_txt(grid: List[List[int]], path: str) -> None:
    with open(path, "w", encoding="utf-8") as f:
        for row in grid:
            f.write("".join(str(x) for x in row) + "\n")

def load_grid_txt(path: str) -> List[List[int]]:
    grid = []
    with open(path, "r", encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            grid.append([0 if ch=='0' else 1 for ch in line])
    return grid
