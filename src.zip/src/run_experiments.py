"""
Run experiments comparing A* vs Weighted A* on random mazes.
Outputs CSV and charts.
"""
from __future__ import annotations
import csv, os
from typing import List, Tuple
import numpy as np
import matplotlib.pyplot as plt
from astar_weighted import astar
from maze_gen import gen_connected_grid, save_grid_txt

def run(out_dir: str, *, sizes=[30, 50, 80], obstacle_ps=[0.25, 0.30, 0.35], seeds=range(5),
        weights=[1.0, 1.2, 1.5, 2.0], allow_diagonal=False) -> str:
    os.makedirs(out_dir, exist_ok=True)
    csv_path = os.path.join(out_dir, "results.csv")
    with open(csv_path, "w", newline="", encoding="utf-8") as f:
        w = csv.writer(f)
        w.writerow(["n","m","obstacle_p","seed","weight","diag","time_s","expansions","path_cost","path_len"])
        for n in sizes:
            for p in obstacle_ps:
                for seed in seeds:
                    grid = gen_connected_grid(n,n,p,seed)
                    start, goal = (0,0), (n-1,n-1)
                    if n==sizes[0] and p==obstacle_ps[0] and seed==0:
                        save_grid_txt(grid, os.path.join(out_dir, "sample_grid.txt"))
                    for weight in weights:
                        path, stats = astar(grid, start, goal, weight=weight, allow_diagonal=allow_diagonal)
                        w.writerow([n,n,p,seed,weight,int(allow_diagonal),
                                    stats["time_s"], stats["expansions"], stats["path_cost"], stats["path_len"]])
    return csv_path

def plot(csv_path: str, out_dir: str) -> None:
    import pandas as pd
    df = pd.read_csv(csv_path)
    g = df.groupby(["n","obstacle_p","weight"], as_index=False)[["expansions","time_s","path_cost"]].mean()

    p_sel = sorted(df["obstacle_p"].unique())[1] if len(df["obstacle_p"].unique())>1 else df["obstacle_p"].unique()[0]
    dfp = g[g["obstacle_p"]==p_sel]
    for metric in ["expansions","time_s","path_cost"]:
        plt.figure()
        for n in sorted(dfp["n"].unique()):
            dfn = dfp[dfp["n"]==n].sort_values("weight")
            plt.plot(dfn["weight"], dfn[metric], marker="o", label=f"n={n}")
        plt.xlabel("weight (w)")
        plt.ylabel(f"mean {metric}")
        plt.title(f"Weighted A*: {metric} vs weight (obstacle_p={p_sel})")
        plt.legend()
        plt.tight_layout()
        plt.savefig(os.path.join(out_dir, f"{metric}_vs_weight.png"), dpi=200)
        plt.close()

if __name__ == "__main__":
    out_dir = os.path.join(os.path.dirname(__file__), "results")
    csv_path = run(out_dir)
    plot(csv_path, out_dir)
    print("Saved:", csv_path)
